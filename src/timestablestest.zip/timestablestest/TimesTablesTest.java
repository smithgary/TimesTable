/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timestablestest;

/**
 *
 * @author garysmith
 */
public class TimesTablesTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //TEST Division Option..
        //TTFrameOption f = new TTFrameOption();
        //f.startup();
        //f.setVisible(true);
        
        TTFrame f = new TTFrame();
        f.startup();
        f.setVisible(true);
        
    }
    
}
